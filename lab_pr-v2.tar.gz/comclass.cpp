#include "comclass.h"


ComClass::ComClass(ComClass *cprev, ComClass *cnext, int tr_n)
{

   train_number=tr_n;
}

ComClass::ComClass(ComClass *cprev, ComClass *cnext)
{

}

ComClass::~ComClass()
{

}



